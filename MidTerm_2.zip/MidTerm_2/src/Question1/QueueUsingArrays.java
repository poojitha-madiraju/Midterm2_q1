package Question1;

public class QueueUsingArrays {
	   private int[] arr;
	   private int front;
	   private int rear;
	   private int size;

	   // Creating Constructor
	   public QueueUsingArrays(int capacity) {
	       arr = new int[capacity];
	       front = 0;
	       rear = -1;
	       size = 0;
	   }
	   
	   // Adds the element in the queue
	   public void enqueue(int item) {
	       if (isFull()) {
	           System.out.println("Queue is full");
	           return;
	       }
	       rear++;
	       arr[rear] = item;
	       size++;
	   }
	   
	   // Removes the element from the queue
	   public int dequeue() {
	       if (isEmpty()) {
	           System.out.println("Queue is empty");
	           return -1;
	       }
	       int item = arr[front];
	       front++;
	       size--;
	       return item;
	   }
	   
	   // Returns the front element in the queue
	   public int peek() {
	       if (isEmpty()) {
	           System.out.println("Queue is empty");
	           return -1;
	       }
	       return arr[front];
	   }
	   
	   // Returns a boolean value if queue is empty
	   public boolean isEmpty() {
	       return size == 0;
	   }
	   
	   // Returns a boolean value if queue is full
	   public boolean isFull() {
	       return rear == arr.length - 1;
	   }
	   
	   // Returns size of the queue
	   public int size() {
	       return size;
	   }
	 
	 public static void main(String[] args)   
	  {  
	    QueueUsingArrays queue = new QueueUsingArrays(5);  
	    queue.enqueue(7);  
	    queue.enqueue(9);  
	    System.out.println("Peek element: "+queue.peek());
	    System.out.println("Deleted element: " + queue.dequeue());  
	    System.out.println("Deleted element: " + queue.dequeue());  
	    queue.enqueue(11);      
	    System.out.println("Deleted element: " + queue.dequeue());      
	  }  
	}