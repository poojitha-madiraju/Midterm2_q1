package Question1;



public class PrintQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    PrintQueue q = new PrintQueue();
		
		q.addEQ(10);
		q.addEQ(20);
		q.addEQ(30);
		q.addEQ(40);
		q.addEQ(50);
		q.printme();
		System.out.println("================");
		q.removeEQ();
		q.printme();
		
		
		q.addEQ(10);
		q.printme();
		
		q.removeEQ();
		q.printme();
		
		System.out.println("========the front is ======");
		q.fronQ();
	}

	private void fronQ() {
		// TODO Auto-generated method stub
		
	}

	private void printme() {
		// TODO Auto-generated method stub
		
	}

	private void removeEQ() {
		// TODO Auto-generated method stub
		
	}

	private void addEQ(int i) {
		// TODO Auto-generated method stub
		
	}

	}


